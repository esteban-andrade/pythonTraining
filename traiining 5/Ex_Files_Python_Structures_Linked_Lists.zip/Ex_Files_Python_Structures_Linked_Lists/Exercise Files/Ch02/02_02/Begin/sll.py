class SLLNode:

    def __init__(self, data):
        self.data = data
        self.next = None

    def get_data(self):
        pass

    def set_data(self, new_data):
        pass

    def get_next(self):
        pass

    def set_next(self, new_next):
        pass
