class Deque:

    def __init__(self):
        self.items = []

    def add_front(self, item):
        pass

    def add_rear(self, item):
        pass

    def remove_front(self):
        pass

    def remove_rear(self):
        pass

    def peek_front(self):
        pass

    def peek_rear(self):
        pass

    def size(self):
        pass

    def is_empty(self):
        pass
