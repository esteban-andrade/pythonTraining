class Queue:

    def __init__(self):
        self.items = []

    def enqueue(self, item):
        pass

    def dequeue(self):
        pass
        
    def peek(self):
        pass

    def size(self):
        pass

    def is_empty(self):
        pass
